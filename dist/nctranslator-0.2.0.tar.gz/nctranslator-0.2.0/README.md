## Nucleotide Translator

This is a simple translation tool which processes nucleotide sequences into aminoacid sequences.