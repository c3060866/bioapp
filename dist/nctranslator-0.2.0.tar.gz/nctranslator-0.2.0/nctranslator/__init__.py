# from nctranslator import *
# from sequence import *